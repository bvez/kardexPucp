namespace Entidades
{
    public enum Sexo { Hombre, Mujer };
}