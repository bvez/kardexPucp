﻿namespace Entidades
{
    public enum EstadoVenta { Registrado, Aprobado, Procesando, Completado};
}