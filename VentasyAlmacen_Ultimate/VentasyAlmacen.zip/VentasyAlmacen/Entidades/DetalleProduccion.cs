namespace Entidades
{
    public class DetalleProduccion
    {

    }
}