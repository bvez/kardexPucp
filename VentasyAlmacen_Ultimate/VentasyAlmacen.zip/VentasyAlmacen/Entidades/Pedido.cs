namespace Entidades
{
    public class Pedido
    {

    }
}