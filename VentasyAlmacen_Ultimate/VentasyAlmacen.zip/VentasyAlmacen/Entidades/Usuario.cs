namespace Entidades
{
    public class Usuario
    {

    }
}